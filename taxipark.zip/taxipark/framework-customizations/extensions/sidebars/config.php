<?php

$cfg = array();

$cfg['dynamic_sidebar_args'] = array(
	'before_widget' => '<aside id="%1$s" class="widget %2$s"><div class="content">',
	'after_widget'  => '</div></aside>',
	'before_title'  => '</div><div class="header">',
	'after_title'   => '</div><div class="content">',
);

