<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'taxipark';

$manifest['supported_extensions'] = array(
	'backups' => array(),
);
