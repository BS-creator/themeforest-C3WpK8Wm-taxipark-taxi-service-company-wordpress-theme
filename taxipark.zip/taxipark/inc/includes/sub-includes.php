<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*
 * Add Featured Content functionality.
 *
 */

