<?php
/**
 * Template Name: Blog
 */

get_template_part( 'blog' );

