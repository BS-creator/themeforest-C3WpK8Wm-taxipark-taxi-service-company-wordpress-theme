<?php
/**
 * Template Name: Gallery
 */

get_template_part( 'archive-gallery' );

